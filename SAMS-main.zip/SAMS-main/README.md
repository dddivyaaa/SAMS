# SAMS-SSN-IT
Student Attendance Management System for IT Department of SSN.
